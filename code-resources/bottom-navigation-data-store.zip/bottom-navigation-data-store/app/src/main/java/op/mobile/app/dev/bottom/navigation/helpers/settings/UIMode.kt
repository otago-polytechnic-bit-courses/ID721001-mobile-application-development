package op.mobile.app.dev.bottom.navigation.helpers.settings

enum class UIMode {
    LIGHT,
    DARK
}
