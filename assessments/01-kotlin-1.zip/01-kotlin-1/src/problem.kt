fun main() {
    var a: String = "Hello, World!"
    println(a) // Hello, World!
}